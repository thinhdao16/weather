export const data_role =[
    'Admin',
    'User',
    'Manager',
    'Auditor'
]